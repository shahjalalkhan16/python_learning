num1 = int(input("Enter your first number: "))
num2 = int(input("Enter your second number: "))

print("Sum of two numbers", num1+num2)

s1 = str(input("Enter your first srting: "))
s2 = str(input("Enter your second string: "))

print("Concate of two string", s1 +  " " + s2)