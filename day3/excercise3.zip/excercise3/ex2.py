dict1 = {"category":"cars", "band" : "porsche", "model": "911 GT"}
dict2 = {"category":"cars", "band" : "abc", "model": "912 GT"}

stack = []

stack.append(dict1)
stack.append(dict2)
print(stack)